<?php

namespace APP\plugins\generic\gestCrossrefProvider;

use PKP\core\JSONMessage;
use PKP\linkAction\LinkAction;
use PKP\linkAction\request\AjaxModal;
use PKP\plugins\GenericPlugin;

class GestCrossrefProviderPlugin extends GenericPlugin
{
    public function getDisplayName()
    {
        return 'GEST Crossref Provider';
    }

    public function getDescription()
    {
        return 'GEST Crossref Service Provider integration for OJS.';
    }

    public function getActions($request, $actionArgs)
    {
        $actions = parent::getActions($request, $actionArgs);

        if (!$this->getEnabled()) {
            return $actions;
        }

        $router = $request->getRouter();

        $url = $router->url(
            $request,
            null,
            null,
            'manage',
            null,
            [
                'verb' => 'settings',
                'plugin' => $this->getName(),
                'category' => 'generic'
            ]
        );

        array_unshift(
            $actions,
            new LinkAction(
                'settings',
                new AjaxModal($url, $this->getDisplayName()),
                __('manager.plugins.settings')
            )
        );

        return $actions;
    }

    public function manage($args, $request)
    {
        $context = $request->getContext();

        if (!$context) {
            return new JSONMessage(false, 'No journal context is available.');
        }

        $contextId = (int) $context->getId();

        $serviceUrl = (string) (
            $this->getSetting($contextId, 'serviceUrl')
            ?: 'https://crossref.gest.co.in'
        );

        $apiKey = (string) (
            $this->getSetting($contextId, 'apiKey')
            ?: ''
        );

        $mode = (string) (
            $this->getSetting($contextId, 'mode')
            ?: 'demo'
        );

        $action = (string) $request->getUserVar('gestAction');

        if ($action === 'save') {
            $serviceUrl = rtrim(
                trim((string) $request->getUserVar('serviceUrl')),
                '/'
            );

            $apiKey = trim((string) $request->getUserVar('apiKey'));
            $mode = (string) $request->getUserVar('mode');

            if ($serviceUrl === '') {
                $serviceUrl = 'https://crossref.gest.co.in';
            }

            if (!in_array($mode, ['demo', 'production'], true)) {
                $mode = 'demo';
            }

            $this->updateSetting($contextId, 'serviceUrl', $serviceUrl);
            $this->updateSetting($contextId, 'apiKey', $apiKey);
            $this->updateSetting($contextId, 'mode', $mode);

            return $this->renderSettings(
                $serviceUrl,
                $apiKey,
                $mode,
                'Settings saved successfully.'
            );
        }

        if ($action === 'test') {
            $result = $this->testConnection($serviceUrl, $apiKey);

            return $this->renderSettings(
                $serviceUrl,
                $apiKey,
                $mode,
                $result
            );
        }

        if ($action === 'demoDeposit') {
            $result = $this->demoDeposit(
                $serviceUrl,
                $apiKey,
                $request
            );

            return $this->renderSettings(
                $serviceUrl,
                $apiKey,
                $mode,
                $result
            );
        }

        return $this->renderSettings(
            $serviceUrl,
            $apiKey,
            $mode,
            ''
        );
    }

    private function renderSettings($serviceUrl, $apiKey, $mode, $message)
    {
        $safeUrl = htmlspecialchars($serviceUrl, ENT_QUOTES, 'UTF-8');
        $safeKey = htmlspecialchars($apiKey, ENT_QUOTES, 'UTF-8');

        $safeMessage = '';

        if ($message !== '') {
            $isSuccess = stripos($message, 'successful') !== false
                || stripos($message, 'saved') !== false;

            $border = $isSuccess ? '#70a57c' : '#c9d7df';
            $background = $isSuccess ? '#f2faf4' : '#f5f9fb';

            $safeMessage =
                '<div style="margin:0 0 18px;padding:12px 14px;border:1px solid '
                . $border
                . ';border-radius:6px;background:'
                . $background
                . ';">'
                . htmlspecialchars($message, ENT_QUOTES, 'UTF-8')
                . '</div>';
        }

        $html = '
        <div id="gest-crossref-settings" style="padding:25px;max-width:760px;">
            <h2 style="margin-top:0;">GEST Crossref Provider</h2>

            <p>
                Configure this OJS journal to communicate with
                the GEST Crossref Service Provider.
            </p>

            <div id="gest-result">' . $safeMessage . '</div>

            <form id="gest-settings-form" method="post"
                  action="' . htmlspecialchars(
                      $this->getSettingsUrl($serviceUrl),
                      ENT_QUOTES,
                      'UTF-8'
                  ) . '">

                <input type="hidden" name="verb" value="settings">

                <div style="margin:16px 0;">
                    <label><strong>GEST Service URL</strong></label><br>
                    <input type="url"
                           name="serviceUrl"
                           value="' . $safeUrl . '"
                           style="width:100%;max-width:650px;padding:8px;"
                           required>
                </div>

                <div style="margin:16px 0;">
                    <label><strong>GEST API Key</strong></label><br>
                    <input type="password"
                           name="apiKey"
                           value="' . $safeKey . '"
                           style="width:100%;max-width:650px;padding:8px;"
                           autocomplete="off">
                </div>

                <div style="margin:16px 0;">
                    <label><strong>Mode</strong></label><br>
                    <select name="mode" style="padding:8px;">
                        <option value="demo" ' .
                        ($mode === 'demo' ? 'selected' : '') .
                        '>Demo</option>
                        <option value="production" ' .
                        ($mode === 'production' ? 'selected' : '') .
                        '>Production</option>
                    </select>
                </div>

                <div style="margin-top:22px;">
                    <button type="submit"
                            name="gestAction"
                            value="save"
                            class="pkp_button">
                        Save Settings
                    </button>

                    <button type="submit"
                            name="gestAction"
                            value="test"
                            class="pkp_button">
                        Test GEST Connection
                    </button>
                </div>
            </form>
            <hr style="margin:28px 0;border:0;border-top:1px solid #ddd;">

            <h3>Demo Article Deposit</h3>
            <p>
                This sends a <strong>local demo deposit</strong> to the GEST service.
                Crossref is not contacted while GEST is in demo mode.
            </p>

            <form id="gest-demo-form" method="post"
                  action="' . htmlspecialchars($this->getSettingsUrl($serviceUrl), ENT_QUOTES, 'UTF-8') . '">

                <input type="hidden" name="verb" value="settings">

                <div style="margin:12px 0;">
                    <label><strong>GEST Client ID</strong></label><br>
                    <input type="text" name="clientId" value="1"
                           style="width:100%;max-width:650px;padding:8px;">
                </div>

                <div style="margin:12px 0;">
                    <label><strong>Demo DOI</strong></label><br>
                    <input type="text" name="doi"
                           value="10.99999/ojs-demo-001"
                           style="width:100%;max-width:650px;padding:8px;">
                </div>

                <div style="margin:12px 0;">
                    <label><strong>Journal Title</strong></label><br>
                    <input type="text" name="journalTitle"
                           value="GEST Crossref Demonstration Journal"
                           style="width:100%;max-width:650px;padding:8px;">
                </div>

                <div style="margin:12px 0;">
                    <label><strong>Article Title</strong></label><br>
                    <input type="text" name="articleTitle"
                           value="GEST Crossref Service Provider Integration Test"
                           style="width:100%;max-width:650px;padding:8px;">
                </div>

                <div style="margin:12px 0;">
                    <label><strong>Author Given Name</strong></label><br>
                    <input type="text" name="authorGiven"
                           value="Test"
                           style="width:100%;max-width:650px;padding:8px;">
                </div>

                <div style="margin:12px 0;">
                    <label><strong>Author Family Name</strong></label><br>
                    <input type="text" name="authorFamily"
                           value="Author"
                           style="width:100%;max-width:650px;padding:8px;">
                </div>

                <div style="margin:12px 0;">
                    <label><strong>Publication Year</strong></label><br>
                    <input type="text" name="publicationYear" value="2026"
                           style="width:100%;max-width:650px;padding:8px;">
                </div>

                <div style="margin:12px 0;">
                    <label><strong>Article URL</strong></label><br>
                    <input type="url" name="resourceUrl"
                           value="https://ojs.gest.co.in/index.php/ojs/article/view/1"
                           style="width:100%;max-width:650px;padding:8px;">
                </div>

                <div id="gest-demo-result" style="margin:16px 0;"></div>

                <button type="submit"
                        name="gestAction"
                        value="demoDeposit"
                        class="pkp_button">
                    Send Demo Deposit to GEST
                </button>
            </form>
        </div>

        <script>
        (function() {
            var form = document.getElementById("gest-settings-form");
            if (!form || form.dataset.gestBound === "1") return;
            form.dataset.gestBound = "1";

            form.addEventListener("submit", function(event) {
                event.preventDefault();

                var result = document.getElementById("gest-result");
                var button = event.submitter;
                var data = new FormData(form);

                if (button && button.name) {
                    data.set(button.name, button.value);
                }

                result.innerHTML =
                    "<div style=\"padding:12px 14px;border:1px solid #c9d7df;border-radius:6px;background:#f5f9fb;\">Processing...</div>";

                fetch(form.action, {
                    method: "POST",
                    body: data,
                    credentials: "same-origin",
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    }
                })
                .then(function(response) {
                    return response.text();
                })
                .then(function(text) {
                    var parsed = null;

                    try {
                        parsed = JSON.parse(text);
                    } catch (e) {}

                    if (parsed && parsed.content) {
                        var wrapper = document.createElement("div");
                        wrapper.innerHTML = parsed.content;

                        var newResult = wrapper.querySelector("#gest-result");
                        if (newResult) {
                            result.innerHTML = newResult.innerHTML;
                        } else {
                            result.innerHTML = parsed.content;
                        }

                        var newForm = wrapper.querySelector("#gest-settings-form");
                        if (newForm) {
                            form.innerHTML = newForm.innerHTML;
                        }
                    } else {
                        result.innerHTML =
                            "<div style=\"padding:12px 14px;border:1px solid #c9d7df;border-radius:6px;background:#f5f9fb;\">"
                            + "Server response received."
                            + "</div>";
                    }
                })
                .catch(function(error) {
                    result.innerHTML =
                        "<div style=\"padding:12px 14px;border:1px solid #d77;border-radius:6px;background:#fff5f5;\">"
                        + "Request failed: " + error.message
                        + "</div>";
                });
            });
            var demoForm = document.getElementById("gest-demo-form");
            if (demoForm && demoForm.dataset.gestBound !== "1") {
                demoForm.dataset.gestBound = "1";

                demoForm.addEventListener("submit", function(event) {
                    event.preventDefault();

                    var result = document.getElementById("gest-demo-result");
                    var data = new FormData(demoForm);
                    data.set("gestAction", "demoDeposit");

                    result.innerHTML =
                        "<div style=\"padding:12px 14px;border:1px solid #c9d7df;border-radius:6px;background:#f5f9fb;\">Sending demo deposit...</div>";

                    fetch(demoForm.action, {
                        method: "POST",
                        body: data,
                        credentials: "same-origin",
                        headers: {"X-Requested-With": "XMLHttpRequest"}
                    })
                    .then(function(response) { return response.text(); })
                    .then(function(text) {
                        var parsed = null;
                        try { parsed = JSON.parse(text); } catch (e) {}

                        if (parsed && parsed.content) {
                            var wrapper = document.createElement("div");
                            wrapper.innerHTML = parsed.content;

                            var source = wrapper.querySelector("#gest-result");
                            if (source) {
                                result.innerHTML = source.innerHTML;
                            } else {
                                result.innerHTML = parsed.content;
                            }
                        } else {
                            result.innerHTML =
                                "<div style=\"padding:12px 14px;border:1px solid #d77;border-radius:6px;background:#fff5f5;\">Unexpected server response.</div>";
                        }
                    })
                    .catch(function(error) {
                        result.innerHTML =
                            "<div style=\"padding:12px 14px;border:1px solid #d77;border-radius:6px;background:#fff5f5;\">Request failed: "
                            + error.message + "</div>";
                    });
                });
            }
        })();
        </script>';

        return new JSONMessage(true, $html);
    }

    private function demoDeposit($serviceUrl, $apiKey, $request)
    {
        $url = rtrim($serviceUrl, '/') . '/api/deposit/test';

        $clientId = (int) $request->getUserVar('clientId');
        $doi = trim((string) $request->getUserVar('doi'));
        $journalTitle = trim((string) $request->getUserVar('journalTitle'));
        $articleTitle = trim((string) $request->getUserVar('articleTitle'));
        $given = trim((string) $request->getUserVar('authorGiven'));
        $family = trim((string) $request->getUserVar('authorFamily'));
        $year = (int) $request->getUserVar('publicationYear');
        $resourceUrl = trim((string) $request->getUserVar('resourceUrl'));

        if ($clientId <= 0 || $doi === '' || $journalTitle === '' || $articleTitle === '') {
            return 'Demo deposit failed: client ID, DOI, journal title and article title are required.';
        }

        $payload = [
            'client_id' => $clientId,
            'doi' => $doi,
            'journal_title' => $journalTitle,
            'title' => $articleTitle,
            'authors' => [
                [
                    'sequence' => 'first',
                    'given' => $given,
                    'family' => $family
                ]
            ],
            'resource_url' => $resourceUrl,
            'record_type' => 'journal_article',
            'live' => false
        ];

        $headers = [
            'Accept: application/json',
            'Content-Type: application/json',
            'User-Agent: GEST-OJS-Crossref-Provider/1.3.0'
        ];

        if ($apiKey !== '') {
            $headers[] = 'Authorization: Bearer ' . $apiKey;
            $headers[] = 'X-GEST-API-Key: ' . $apiKey;
        }

        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_FOLLOWLOCATION => true,
        ]);

        $body = curl_exec($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $error !== '') {
            return 'Demo deposit failed: ' . ($error ?: 'Unknown cURL error');
        }

        $decoded = json_decode($body, true);

        if ($status >= 200 && $status < 300) {
            if (is_array($decoded)) {
                $state = $decoded['status'] ?? 'success';
                $submissionId = $decoded['submission_id'] ?? ($decoded['id'] ?? 'n/a');
                $mode = $decoded['mode'] ?? 'demo';

                return 'Demo deposit successful. HTTP ' . $status
                    . '. GEST status: ' . $state
                    . '. Submission ID: ' . $submissionId
                    . '. Mode: ' . $mode
                    . '. Crossref was not contacted.';
            }

            return 'Demo deposit successful. HTTP ' . $status . '. Crossref was not contacted.';
        }

        $detail = '';
        if (is_array($decoded)) {
            $detail = $decoded['error'] ?? $decoded['message'] ?? '';
        }
        if ($detail === '') {
            $detail = trim(strip_tags($body));
        }

        return 'Demo deposit returned HTTP ' . $status
            . ($detail !== '' ? ': ' . $detail : '.');
    }

    private function getSettingsUrl($serviceUrl)
    {
        // The form is posted back to the current OJS route.
        // The actual service URL is intentionally not used here.
        return $_SERVER['REQUEST_URI'] ?? '';
    }

    private function testConnection($serviceUrl, $apiKey)
    {
        $url = rtrim($serviceUrl, '/') . '/api/health';

        $headers = [
            'Accept: application/json',
            'User-Agent: GEST-OJS-Crossref-Provider/1.2.0'
        ];

        if ($apiKey !== '') {
            $headers[] = 'Authorization: Bearer ' . $apiKey;
            $headers[] = 'X-GEST-API-Key: ' . $apiKey;
        }

        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_FOLLOWLOCATION => true,
        ]);

        $body = curl_exec($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        if ($body === false || $error !== '') {
            return 'Connection failed: ' .
                ($error ?: 'Unknown cURL error');
        }

        if ($status >= 200 && $status < 300) {
            return 'GEST connection successful. HTTP ' . $status . '.';
        }

        return 'GEST connection returned HTTP ' . $status . '.';
    }
}
